# -*- coding: utf-8 -*-
# from odoo import http


# class RmaHr(http.Controller):
#     @http.route('/rma_hr/rma_hr', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/rma_hr/rma_hr/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('rma_hr.listing', {
#             'root': '/rma_hr/rma_hr',
#             'objects': http.request.env['rma_hr.rma_hr'].search([]),
#         })

#     @http.route('/rma_hr/rma_hr/objects/<model("rma_hr.rma_hr"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('rma_hr.object', {
#             'object': obj
#         })
