# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ValidationEmployee(models.Model):
    _name = 'validation.employee'
    _description = 'The model is Employee`s Validation'

    active = fields.Boolean(string="Active/Inactive", default=True)
    local = fields.Selection([
        ('local', 'Local'),
        ('expat', 'Expat')]
        , string="Local/Expat")
    entity = fields.Char(string="Entity")
    location = fields.Selection([
        ('mv -ford', 'MV - Ford'),
        ('phnom penh - avr', 'Phnom Penh - AVR'),
        ('phnon penh - bspf', 'Phnon Penh - BSPF'),
        ('Phnom Penh - Finance', 'Phnom Penh - Finance'),
        ('Phnom Penh - Ford', 'Phnom Penh - Ford'),
        ('Phnom Penh - HR', 'Phnom Penh - HR'),
        ('Phnom Penh - PGG', 'Phnom Penh - PGG'),
        ('Pursat - CKD', 'Pursat - CKD'),
        ('Tbong Khmum - AED', 'Tbong Khmum - AED'),
        ('TSK - Ford', 'TSK - Ford'),
        ('Kampong Speu - AED', 'Kampong Speu - AED'),
        ('Phnom Penh - AED', 'Phnom Penh - AED'),
        ('Phnom Penh - Logistics', 'Phnom Penh - Logistics'),
        ('Phnom Penh - Executive', 'Phnom Penh - Executive'),
        ('Mondulkiri - AED', 'Mondulkiri - AED'),
        ('Phnom Penh - HED', 'Phnom Penh - HED'),
        ('Koh Kong - AED', 'Koh Kong - AED'),
        ('Kratié - AED', 'Kratié - AED'),
        ('Battambang - AED', 'Battambang - AED'),
        ('Banteay Meanchey - AED', 'Banteay Meanchey - AED'),
        ('Kampong Cham - Ford', 'Kampong Cham - Ford'),
        ('Pursat - AED', 'Pursat - AED'),
        ('Svay Rieng - AED', 'Svay Rieng - AED'),
        ('Ratanakiri - AED', 'Ratanakiri - AED'),
        ('N6A - Ford', 'N6A - Ford'),
        ('Steung Treng - AED', 'Steung Treng - AED'),
        ('Phnom Penh - CKD', 'Phnom Penh - CKD'),
        ('Kampong Cham - AED', 'Kampong Cham - AED'),
        ('Kampong Thom - AED', 'Kampong Thom - AED'),
        ('Phnom Penh - Changan', 'Phnom Penh - Changan'),
        ('Takeo - AED', 'Takeo - AED'),
        ('Phnom Penh - SP', 'Phnom Penh - SP'),
        ('QL - Ford', 'QL - Ford'),
        ('Phnom Penh - Digital Business & IT', 'Phnom Penh - Digital Business & IT'),
        ('THH - Ford', 'THH - Ford'),
        ('Phnom Penh - JLR', 'Phnom Penh - JLR'),
        ('Siem Reap - AED', 'Siem Reap - AED'),
        ('Kampot - AED', 'Kampot - AED'),
        ('Prey Veng - AED', 'Prey Veng - AED'),
        ('Pursat', 'Pursat'),
        ('Pailin - AED', 'Pailin - AED'),
        ('Preah Vihear - AED', 'Preah Vihear - AED'),
        ('Pursat - HED', 'Pursat - HED'),
        ('Oddar Meachey - AED', 'Oddar Meachey - AED')
    ], string="Location")
    type_of_employment = fields.Selection([
        ('FullTime', 'Full Time'),
        ('Part Time', 'Part Time'),
        ('Fixed Term', 'Fixed Term')],
        string="Type Of Employment")
    employee_level = fields.Selection([
        ('Manager', 'Manager'),
        ('professional/supervisor', 'Professional/Supervisor'),
        ('operational', 'Operational')],
        string="Employee Level")
    job_grade = fields.Integer(string="Job Grade")
    notice_period = fields.Integer(string="Notice Period")
    leaving_type = fields.Selection([
        ('resign', 'Resign'),
        ('retire', 'Retire'),
        ('redundant/separation', 'Redundant/Separation'),
        ('terminate/not pass probation', 'Terminate/Not pass probation'),
        ('Transfer inter-country', 'Transfer Inter-Country'),
        ('others: deceased/end contract', 'Others: Deceased/End Contract')],
        string="Leaving Type")
    reason_of_resign = fields.Selection([
        ('work relation', 'Work Relation'),
        ('career dev', 'Career Dev'),
        ('personal reason', 'Personal Reason'),
        ('com & ben', 'Com & Ben'),
        ('work condition', 'Work Condition')]
        , string="Reason Of Resign")
    phone_allowance = fields.Char(string="Phone Allowance")
    company_car = fields.Char(string="Company Car")
    education_allowance = fields.Selection([
        ('old policy', 'Old Policy'),
        ('new policy', 'New Policy')],
        string="Education Allowance")
    hearth_insurance = fields.Char(string="Hearth Insurance")
    personal_accidental_insurance = fields.Char(string="Personal Accidental Insurance")
    life_insurance = fields.Char(string="Life Insurance(Prudential)")
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other')]
        , string="Sex")
    marital_status = fields.Selection([
        ('single', 'Single'),
        ('married', 'Married'),
        ('widowed', 'Widowed'),
        ('divorced', 'Divorced')]
        , string="Marital Status")
    local_back = fields.Selection([
        ('acleda bank', 'ACLEDA Bank'),
        ('aba', 'ABA'),
        ('cash', 'Cash'),
        ('cimb', 'CIMB'),
        ('j trust royal bank', 'J Trust Royal Bank')]
        , string="Local Bank Details")
    sources = fields.Char(string="Sources")


