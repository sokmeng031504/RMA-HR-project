# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ConfigurationEmployee(models.Model):
    _name = 'config.employee'
    _description = 'this is fields for configuration employee'

    name = fields.Char(string="Create Job")
    department = fields.Char(string="Department")
    employment_Type = fields.Char(string="Employment Type")
