# -*- coding: utf-8 -*-

from odoo import models, fields, api


class EmploymentInfor(models.Model):
    _name = 'employment.infor'
    _description = 'This is module for Employment information'

    active = fields.Boolean(string="Active/Inactive", default=True)
    local = fields.Selection([
        ('local', 'Local'),
        ('expat', 'Expat')]
        , string="Local/Expat")
    entity = fields.Char(string="Entity")
    cost_center = fields.Char(string="Cost Center")
    cost_center_number = fields.Integer(string="Cost Center Number")
    location = fields.Selection([
        ('mv -ford', 'MV - Ford'),
        ('phnom penh - avr', 'Phnom Penh - AVR'),
        ('phnon penh - bspf', 'Phnon Penh - BSPF'),
        ('Phnom Penh - Finance', 'Phnom Penh - Finance'),
        ('Phnom Penh - Ford', 'Phnom Penh - Ford'),
        ('Phnom Penh - HR', 'Phnom Penh - HR'),
        ('Phnom Penh - PGG', 'Phnom Penh - PGG'),
        ('Pursat - CKD', 'Pursat - CKD'),
        ('Tbong Khmum - AED', 'Tbong Khmum - AED'),
        ('TSK - Ford', 'TSK - Ford'),
        ('Kampong Speu - AED', 'Kampong Speu - AED'),
        ('Phnom Penh - AED', 'Phnom Penh - AED'),
        ('Phnom Penh - Logistics', 'Phnom Penh - Logistics'),
        ('Phnom Penh - Executive', 'Phnom Penh - Executive'),
        ('Mondulkiri - AED', 'Mondulkiri - AED'),
        ('Phnom Penh - HED', 'Phnom Penh - HED'),
        ('Koh Kong - AED', 'Koh Kong - AED'),
        ('Kratié - AED', 'Kratié - AED'),
        ('Battambang - AED', 'Battambang - AED'),
        ('Banteay Meanchey - AED', 'Banteay Meanchey - AED'),
        ('Kampong Cham - Ford', 'Kampong Cham - Ford'),
        ('Pursat - AED', 'Pursat - AED'),
        ('Svay Rieng - AED', 'Svay Rieng - AED'),
        ('Ratanakiri - AED', 'Ratanakiri - AED'),
        ('N6A - Ford', 'N6A - Ford'),
        ('Steung Treng - AED', 'Steung Treng - AED'),
        ('Phnom Penh - CKD', 'Phnom Penh - CKD'),
        ('Kampong Cham - AED', 'Kampong Cham - AED'),
        ('Kampong Thom - AED', 'Kampong Thom - AED'),
        ('Phnom Penh - Changan', 'Phnom Penh - Changan'),
        ('Takeo - AED', 'Takeo - AED'),
        ('Phnom Penh - SP', 'Phnom Penh - SP'),
        ('QL - Ford', 'QL - Ford'),
        ('Phnom Penh - Digital Business & IT', 'Phnom Penh - Digital Business & IT'),
        ('THH - Ford', 'THH - Ford'),
        ('Phnom Penh - JLR', 'Phnom Penh - JLR'),
        ('Siem Reap - AED', 'Siem Reap - AED'),
        ('Kampot - AED', 'Kampot - AED'),
        ('Prey Veng - AED', 'Prey Veng - AED'),
        ('Pursat', 'Pursat'),
        ('Pailin - AED', 'Pailin - AED'),
        ('Preah Vihear - AED', 'Preah Vihear - AED'),
        ('Pursat - HED', 'Pursat - HED'),
        ('Oddar Meachey - AED', 'Oddar Meachey - AED')
    ], string="Location")



