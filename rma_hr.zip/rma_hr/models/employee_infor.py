# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrEmployeeInherit(models.Model):
    _inherit = 'hr.employee'

    # name in english
    name_english = fields.Char(string="Name English", compute='_total_name', required=True)
    first_name_eng = fields.Char(string="Fist name")
    last_name_eng = fields.Char(string="Last name")
    # name in khmer
    first_name_kh = fields.Char(string="KH-First Name")
    last_name_kh = fields.Char(string="KH-Last Name")
    name_khmer = fields.Char(string="Name khmer", compute='_total_name_kh', required=True)
    # vaccine type
    vaccine = fields.Many2many('vaccine.information')
    # # education employee
    education = fields.Many2many('education.information')

    # function name in english
    @api.depends('first_name_eng', 'last_name_eng', 'name_english')
    def _total_name(self):
        for rec in self:
            if rec.first_name_eng or rec.last_name_eng:
                rec.name_english = (rec.first_name_eng or '') + ' ' + (rec.last_name_eng or '')
            else:
                rec.name_english = False

    # function name in khmer
    @api.depends('first_name_kh', 'last_name_kh', 'name_khmer')
    def _total_name_kh(self):
        for rec in self:
            if rec.first_name_kh or rec.last_name_kh:
                rec.name_khmer = (rec.first_name_kh or '') + ' ' + (rec.last_name_kh or '')
            else:
                rec.name_khmer = False
