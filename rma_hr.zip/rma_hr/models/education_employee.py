# *- coding: utf-8 -*-

from odoo import models, fields, api


class EmployeeInformation(models.Model):
    _name = "education.information"
    _description = "This is education employee`s information "

    name_institute = fields.Char(string="Name of institute")
    skill_major = fields.Char(string="Major / Skill")
    education_level = fields.Char(string="Education Level")
    date_of_started = fields.Date(string="Date of started")
    date_of_ended = fields.Date(string="Date of ended")
    gpa_education = fields.Integer(string="GPA")