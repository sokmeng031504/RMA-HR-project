# *- coding: utf-8 -*-

from odoo import models, fields, api


class EmployeeInformation(models.Model):
    _name = "vaccine.information"
    _description = "This is Vaccine employee`s information "

    vaccine_type = fields.Char(string="Vaccine Name")
    vaccine_dose = fields.Integer(string="Dose")
    vaccine_date = fields.Date(string="Date")