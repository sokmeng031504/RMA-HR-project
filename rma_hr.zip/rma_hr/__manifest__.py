# -*- coding: utf-8 -*-
{
    'name': "rma_hr",

    'summary': """
    """,

    'description': """
        this is test rma hr module
    """,

    'author': "Rma cambodia",
    'website': "http://www.rmacambodia.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'hr'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/employee_infor.xml',
        'views/vaccine_information.xml',
        'views/education_employee.xml',
        'views/configuration.xml',
        'views/employment_infor.xml',
        'views/validation.xml',
        'views/cost_center_group.xml',

    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
